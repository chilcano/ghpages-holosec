package info.intix.rabbitmq.samples;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.ConsumerCancelledException;
import com.rabbitmq.client.QueueingConsumer;
import com.rabbitmq.client.ShutdownSignalException;

public class RabbitAMQPReceiver  {

	private final static String QUEUE_NAME = "q.test1";
	private final static String EXCHANGE_NAME = "q.ex.test1";
	private final static String ROUTING_KEY_VALUE = "q.rk.test1";
	private final static boolean AUTO_ACK = true;

	
    public static void main(String[] args) throws IOException, ShutdownSignalException, ConsumerCancelledException, InterruptedException, KeyManagementException, NoSuchAlgorithmException, URISyntaxException {
              
        String hostName = "10.105.135.53";
        String userName = "admin";
        String password = "JRq7b1Ct";
        int port = 5672;
    	String virtualHost = "DES_DEV";
        
        // "amqp://userName:password@hostName:portNumber/virtualHost"
        String strUriRabbitMQ = "amqp://" + userName + ":" + password + "@" + hostName + ":" + port + "/" + virtualHost;
        
        ConnectionFactory connFactory = new ConnectionFactory();
        connFactory.setUri(strUriRabbitMQ);
        
        Connection connection = connFactory.newConnection();
		Channel channel = connection.createChannel();

		//channel.queueDeclare(QUEUE_NAME, false, false, false, null);
		//channel.exchangeDeclare(EXCHANGE_NAME, "direct", true);
		
		channel.queueBind(QUEUE_NAME, EXCHANGE_NAME, ROUTING_KEY_VALUE);
		 
		// Create the consumer
		QueueingConsumer consumer = new QueueingConsumer(channel);
		
		channel.basicConsume(QUEUE_NAME, AUTO_ACK, consumer);
		 
		String strMsgReceivedBody = null;
		boolean isMsgReceived = false;
		QueueingConsumer.Delivery delivery;
		
		// Start consuming messages
		while (!isMsgReceived) {

	      try {
			delivery = consumer.nextDelivery();
			strMsgReceivedBody = new String(delivery.getBody());
			
			if (strMsgReceivedBody != null) {
				
			}
			
          } catch (InterruptedException e) {
        	  System.out.println(" ~> Error while consuming message" + e);
        	  break;
          } finally {
              channel.close();    // close channel with OK
              connection.close(); // close conn and its channels with OK
          }
		  
		}
        
		System.out.println(" ~> message received with AUTO_ACK:\n" + strMsgReceivedBody);
    }
    
}
