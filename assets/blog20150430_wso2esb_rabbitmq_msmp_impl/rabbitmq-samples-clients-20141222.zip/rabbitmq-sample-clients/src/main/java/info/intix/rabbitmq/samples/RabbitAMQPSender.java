package info.intix.rabbitmq.samples;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class RabbitAMQPSender {

	private final static String QUEUE_NAME = "q.test1";
	private final static String EXCHANGE_NAME = "q.ex.test1";
	private final static String ROUTING_KEY_VALUE = "q.rk.test1";


/*
	private final static boolean AUTO_ACK = true;
	
	private final static boolean QUEUE_DURABLE = false;
	private final static boolean QUEUE_EXCLUSIVE = false;
	private final static boolean QUEUE_AUTO_DETELE = false;

	private final static String EXCHANGE_TYPE = "direct";
	private final static boolean EXCHANGE_DURABLE = true;
*/

	private final static String HEADER_MESSAGE_ID = "12345";
	private final static String HEADER_CONTENT_TYPE = "text/xml";
	private final static String HEADER_REPLY_TO_ADDRESS = "test-rabbit-01@test.com";
	private final static String HEADER_CORRELATION_ID = "1234567890";
	private final static String HEADER_CONTENT_ENCODING = "UTF-8";
	
	private final static String HEADER_CUSTOM_SOAP_ACTION_KEY = "SOAP_ACTION";
	private final static String HEADER_CUSTOM_SOAP_ACTION_VALUE = "greet";
	
    public static void main(String[] args) throws IOException, KeyManagementException, NoSuchAlgorithmException, URISyntaxException {
              
        //String hostName = "10.105.135.53";
    	String hostName = "10.105.135.72";
        String userName = "admin";
        String password = "JRq7b1Ct";
        int port = 5672;
    	String virtualHost = "DES_DEV";
        
        // "amqp://userName:password@hostName:portNumber/virtualHost"
        String strUriRabbitMQ = "amqp://" + userName + ":" + password + "@" + hostName + ":" + port + "/" + virtualHost;
        
        ConnectionFactory connFactory = new ConnectionFactory();
        connFactory.setUri(strUriRabbitMQ);
        
        /*
        connFactory.setHost(hostName);
        connFactory.setUsername(userName);
        connFactory.setPassword(password);
        connFactory.setPort(port);
        connFactory.setVirtualHost(VIRTUAL_HOST);
        */

        
        Connection connection = connFactory.newConnection();
        Channel channel = connection.createChannel();
        
        //channel.queueDeclare(QUEUE_NAME, QUEUE_DURABLE, QUEUE_EXCLUSIVE, QUEUE_AUTO_DETELE, null);
        //channel.exchangeDeclare(EXCHANGE_NAME, EXCHANGE_TYPE, EXCHANGE_DURABLE);
        
        // make relation between exchange-to-queue
        channel.queueBind(QUEUE_NAME, EXCHANGE_NAME, ROUTING_KEY_VALUE);
         
        // The message to be sent
        Date date = new Date();
        String name = "Hi RabbitMQ - " + date.toString() + " !";
        
        String message = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                         "<soapenv:Body>\n" +
                         "  <p:greet xmlns:p=\"http://greet.service.foobar.org\">\n" + 
                         "     <in>" + name + "</in>\n" +
                         "  </p:greet>\n" +
                         "</soapenv:Body>\n" +
                         "</soapenv:Envelope>";
         
        // Populate the AMQP message properties
        AMQP.BasicProperties.Builder builder = new AMQP.BasicProperties().builder();
        builder.messageId(HEADER_MESSAGE_ID);
        builder.contentType(HEADER_CONTENT_TYPE);
        builder.replyTo(HEADER_REPLY_TO_ADDRESS);
        builder.correlationId(HEADER_CORRELATION_ID);
        builder.contentEncoding(HEADER_CONTENT_ENCODING);
        
        // Custom user properties
        Map<String, Object> headersCustom = new HashMap<String, Object>();
        headersCustom.put(HEADER_CUSTOM_SOAP_ACTION_KEY, HEADER_CUSTOM_SOAP_ACTION_VALUE);
        builder.headers(headersCustom);
             
        // Publish the message to exchange
        //channel.basicPublish(exchangeName, queueName, builder.build(), message.getBytes());
        channel.basicPublish(EXCHANGE_NAME, ROUTING_KEY_VALUE, builder.build(), message.getBytes());
               
        System.out.println("-> Queue: " + QUEUE_NAME);
        System.out.println("-> Exchange: " + EXCHANGE_NAME);
        System.out.println("-> RoutingKey: " + ROUTING_KEY_VALUE);
        System.out.println("-> Message sent:\n");
        System.out.println(message);
             
        channel.close();    // close channel with OK
        connection.close(); // close conn and its channels with OK
    }

}