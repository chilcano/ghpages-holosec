package info.intix.rabbitmq.samples;

public class test1 {

	public static void main(String[] args) {
		
		String xxx = "abcdefg";
		test1 t1 = new test1();
		t1.method1(xxx);
		System.out.println(" method1 - xxx final : " + xxx);
		
	}

	public test1() {
		// empty constructor
	}
	
	private boolean method1 (String xxx) {
		
		System.out.println(" method1 - xxx ini : " + xxx);
		xxx = xxx + "-123456";
		return true;
		
	}
}
