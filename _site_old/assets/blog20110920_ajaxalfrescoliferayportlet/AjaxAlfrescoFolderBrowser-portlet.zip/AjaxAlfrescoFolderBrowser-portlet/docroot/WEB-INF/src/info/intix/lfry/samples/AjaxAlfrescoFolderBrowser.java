package info.intix.lfry.samples;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

/**
 * Portlet implementation class AjaxAlfrescoFolderBrowser
 */
public class AjaxAlfrescoFolderBrowser extends GenericPortlet {

    public void init() {
        editJSP = getInitParameter("edit-jsp");
        helpJSP = getInitParameter("help-jsp");
        viewJSP = getInitParameter("view-jsp");
    }

	/**
	 * intix: Changes are persisted when the store method is called. 
	 * The store method can only be invoked within the scope of a processAction call. 
	 * Changes that are not persisted are discarded when the processAction or render method ends.
	 */
    public void processAction(
            ActionRequest actionRequest, ActionResponse actionResponse)
        throws IOException, PortletException {

        //super.processAction(actionRequest, actionResponse);
		PortletPreferences prefs = actionRequest.getPreferences();		
		prefs.setValue("ticketUrl", actionRequest.getParameter("ticketUrl"));
		prefs.setValue("alfServer", actionRequest.getParameter("alfServer"));
		prefs.setValue("alfTicketSvc", actionRequest.getParameter("alfTicketSvc"));
		prefs.setValue("alfTicketSvcParams", actionRequest.getParameter("alfTicketSvcParams"));
		prefs.setValue("alfWebscriptBrowserURL", actionRequest.getParameter("alfWebscriptBrowserURL"));
		prefs.setValue("alfWebscriptBrowserURLParams", actionRequest.getParameter("alfWebscriptBrowserURLParams"));
		prefs.setValue("jQuery", actionRequest.getParameter("jQuery"));	
		prefs.store();
		actionResponse.setPortletMode(PortletMode.EDIT);
    }
    
    /**
     * intix:
     */
    public void doEdit(
            RenderRequest renderRequest, RenderResponse renderResponse)
        throws IOException, PortletException {
		if (renderRequest.getPreferences() == null) {
			//super.doEdit(renderRequest, renderResponse);
		} else {
			// get editable preferences
			PortletPreferences prefs = renderRequest.getPreferences();
			
			// intix: these values will override options in portlet.xml
			renderRequest.setAttribute("alfServer", (prefs.getValue("alfServer", "")));
			renderRequest.setAttribute("alfTicketSvc", (prefs.getValue("alfTicketSvc", "")));
			renderRequest.setAttribute("alfTicketSvcParams", (prefs.getValue("alfTicketSvcParams", "")));			
			renderRequest.setAttribute("alfWebscriptBrowserURL", (prefs.getValue("alfWebscriptBrowserURL", "")));
			renderRequest.setAttribute("alfWebscriptBrowserURLParams", (prefs.getValue("alfWebscriptBrowserURLParams", "")));		
			renderRequest.setAttribute("jQuery", (prefs.getValue("jQuery", "")));		
			include(editJSP, renderRequest, renderResponse);
		}
    }
    
    public void doHelp(
            RenderRequest renderRequest, RenderResponse renderResponse)
        throws IOException, PortletException {
        
        include(helpJSP, renderRequest, renderResponse);
    }
    
    /**
     * intix:
     */
    public void doView(
            RenderRequest renderRequest, RenderResponse renderResponse)
        throws IOException, PortletException {
        
		try {
			// get portlet prefs
			PortletPreferences prefs = renderRequest.getPreferences();	
			
			String alfServer = prefs.getValue("alfServer", "");
			String alfTicketSvc = prefs.getValue("alfTicketSvc", "");
			String alfTicketSvcParams = prefs.getValue("alfTicketSvcParams", "");		
			String alfWebscriptBrowserURL= prefs.getValue("alfWebscriptBrowserURL", "");
			String alfWebscriptBrowserURLParams = prefs.getValue("alfWebscriptBrowserURLParams", "");			
			String jQuery = prefs.getValue("jQuery", "");			
			String ticketUrl = alfServer + alfTicketSvc + "?" + alfTicketSvcParams;
			
			renderRequest.setAttribute("ticketUrl", ticketUrl);			
			renderRequest.setAttribute("alfServer", alfServer);
			renderRequest.setAttribute("alfTicketSvc", alfTicketSvc);
			renderRequest.setAttribute("alfTicketSvcParams", alfTicketSvcParams);		
			renderRequest.setAttribute("alfWebscriptBrowserURL", alfWebscriptBrowserURL);
			renderRequest.setAttribute("alfWebscriptBrowserURLParams", alfWebscriptBrowserURLParams);
			renderRequest.setAttribute("jQuery", jQuery);
		}catch(Exception ex) {
			_log.error(ex);
		}     	
        include(viewJSP, renderRequest, renderResponse);
    }

    protected void include(
            String path, RenderRequest renderRequest,
            RenderResponse renderResponse)
        throws IOException, PortletException {

        PortletRequestDispatcher portletRequestDispatcher =
            getPortletContext().getRequestDispatcher(path);

        if (portletRequestDispatcher == null) {
            _log.error(path + " is not a valid include");
        }
        else {
            portletRequestDispatcher.include(renderRequest, renderResponse);
        }
    }

    /**
     * intix: serveResource does HTTP and Ajax call behind of Liferay
     */
    public void serveResource(ResourceRequest request, ResourceResponse response) throws PortletException, IOException {
    	response.setContentType("text/xml");
		String strAlfTicket= request.getParameter("alf_ticket");	
        String strQueryString = "";
        if (strAlfTicket != null) {
			// intix: if alf_ticket exists, then user was authenticate with alfresco
			Map<String, String[]> mapParameters = request.getParameterMap();
			for (Entry<String, String[]> entryParameter : mapParameters.entrySet()) {
			    System.out.println(">> Key = " + entryParameter.getKey() + ", Value = " + entryParameter.getValue()[0]);		    
			    strQueryString = strQueryString + entryParameter.getKey() + "=" + entryParameter.getValue()[0] + "&";
			}
		} else {
			// intix: ticket is null
			String strUser = request.getParameter("u");
			String strPw = request.getParameter("pw");
			strQueryString = "u=" + strUser + "&pw=" + strPw;
		}
		String requestUrl = request.getResourceID();    
    	BufferedInputStream web2ProxyBuffer = null;
        BufferedOutputStream proxy2ClientBuffer = null;
        HttpURLConnection con;
        URL url = null;
        try {
            int oneByte = 0;
            String methodName;
            if (strAlfTicket != null) {
            	url = new URL(requestUrl + "?" + strQueryString);
            } else {
            	url = new URL(requestUrl);
            }
            con = (HttpURLConnection) url.openConnection();
            methodName = request.getMethod();
            System.out.println(">> methodName: " + methodName);
            
            con.setRequestMethod(methodName);
            con.setDoOutput(true);
            con.setDoInput(true);
            con.setFollowRedirects(false);
            con.setUseCaches(true);
            con.connect();

            // does not work in 6.0.6 CE
            // http://issues.liferay.com/browse/LPS-13039
            int httpRespCode = con.getResponseCode();
            response.setProperty(ResourceResponse.HTTP_STATUS_CODE, Integer.toString(httpRespCode));
            System.out.println(">> HTTP_STATUS_CODE: " + httpRespCode);
                      
            if(methodName.equals("POST")) {
                BufferedInputStream clientToProxyBuf = new BufferedInputStream(request.getPortletInputStream());
                BufferedOutputStream proxyToWebBuf     = new BufferedOutputStream(con.getOutputStream());
                while ((oneByte = clientToProxyBuf.read()) != -1) {
                    proxyToWebBuf.write(oneByte);
                }
                proxyToWebBuf.flush();
                proxyToWebBuf.close();
                clientToProxyBuf.close();
            }

            for( Iterator i = con.getHeaderFields().entrySet().iterator() ; i.hasNext() ;) {
                Map.Entry mapEntry = (Map.Entry)i.next();
                if(mapEntry.getKey()!=null) {
                    //response.setHeader(mapEntry.getKey().toString(), ((List)mapEntry.getValue()).get(0).toString());
                    System.out.println(">> HEADER > " + mapEntry.getKey().toString() + "\t" + ((List)mapEntry.getValue()).get(0).toString());
                }
            }
            
            InputStream in = con.getInputStream();
            web2ProxyBuffer = new BufferedInputStream(in);
            proxy2ClientBuffer = new BufferedOutputStream(response.getPortletOutputStream());

 			byte [] byteArray = new byte[1024]; // intix: any array size is valid
			int intByteRead = web2ProxyBuffer.read(byteArray);
			while (intByteRead > 0) {
				// intix: print response-html/xml, must be the first line after while loop
				System.out.println(new String(byteArray, 0, intByteRead));
				proxy2ClientBuffer.write(byteArray, 0, intByteRead);
				intByteRead = web2ProxyBuffer.read(byteArray);			
			}                 
            proxy2ClientBuffer.flush();
            proxy2ClientBuffer.close();
            web2ProxyBuffer.close();
            con.disconnect();
        } catch(Exception e) {
            e.getMessage();
        } finally {
        	//
        }		
	}         
    
    protected String editJSP;
    protected String helpJSP;
    protected String viewJSP;

    private static Log _log = LogFactoryUtil.getLog(AjaxAlfrescoFolderBrowser.class);

}
